// <activity
// android:name="com.yalantis.ucrop.UCropActivity"
// android:screenOrientation="portrait"
// android:theme="@style/Theme.AppCompat.Light.NoActionBar"
// tools:ignore="MissingClass" />
// <!-- Don't delete the meta-data below.
// This is used by the Flutter tool to generate GeneratedPluginRegistrant.java -->
// <meta-data
// android:name="flutterEmbedding"
// android:value="2" />
// <meta-data android:name="com.google.android.geo.API_KEY"
// android:value="AIzaSyCsIZjH8VgRzQkZPDtkrTxC0iWAENkDbMo"/>


// carousel_slider: ^4.1.1
// dotted_border: ^2.0.0+3
// pull_to_refresh: ^2.0.0
// get:
// http:
// fluttertoast: ^8.0.9
// audioplayers: ^1.1.1
// intl: ^0.17.0
// stroke_text: any
// flutter_polyline_points: ^1.0.0
// geocoding: ^2.0.5
// provider: ^6.0.4
// google_maps_flutter: ^2.2.1
// geolocator: ^9.0.2
// easy_localization: ^3.0.1
// video_player: ^2.5.1
// pinput: any
// syncfusion_flutter_datepicker: ^19.4.56
// firebase_messaging: ^14.3.0
// connectivity_plus: ^3.0.2
// permission_handler: ^10.2.0
// sqflite: ^2.0.2
// image_picker: ^0.8.6+3
// image_cropper: ^3.0.1
// uuid: ^3.0.6
// place_picker: ^0.10.0
// shared_preferences: ^2.0.18
// firebase_database: ^10.0.9
// firebase_core: ^2.4.1
// firebase_auth: ^4.2.5
// cloud_firestore: ^4.4.4
// cached_network_image: ^3.2.3