import 'dart:developer';

import 'package:flutter/material.dart';


class NoPaginationProvider<T> with ChangeNotifier{



}